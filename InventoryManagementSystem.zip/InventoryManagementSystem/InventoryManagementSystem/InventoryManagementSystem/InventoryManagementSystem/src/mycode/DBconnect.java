/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycode;

/**
 *
 * @author POWER
 */
import com.mysql.jdbc.Connection;
import java.sql.DriverManager;

public class DBconnect {
    
    public static Connection connect(){
        
        //define a variable for return which is in the data type, Connection
        Connection conn = null;
        
        //use try catch for a large code/process for get the error
        try{
            
            Class.forName("com.mysql.jdbc.Driver");
            
            //initialize the variable (location.username.password)
            conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/smack","root","");   //casting
        
        }catch(Exception e){
            System.out.println(e);
        }
        
        //return value
        return conn;
    }
}

