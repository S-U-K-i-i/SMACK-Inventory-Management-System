/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycode;

/**
 *
 * @author POWER
 */
public class Validation {
    public static String phonenumber_validation(String contactno) {
          
        int count = 0;        
        //Counts each character except space    
        for(int i = 0; i < contactno.length(); i++) {    
            if(contactno.charAt(i) != ' ')    
                count++;    
        }
           
        if(count>10){
            String score = "true";
            return score;
        }
        else{
            String score = "false";
            return score;
        }
        
     }
    
}
