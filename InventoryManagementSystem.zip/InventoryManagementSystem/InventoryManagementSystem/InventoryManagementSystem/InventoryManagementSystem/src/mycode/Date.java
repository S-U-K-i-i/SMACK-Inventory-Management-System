/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mycode;

import java.text.SimpleDateFormat;

/**
 *
 * @author Layanga
 */
public class Date {
    public static String datesql(){
        java.util.Date date = new java.util.Date();
        String pattern = "YYYY-MM-d";
        SimpleDateFormat formatter = new SimpleDateFormat(pattern);
        String mysqlDateString = formatter.format(date);
        return mysqlDateString;
    }
}
