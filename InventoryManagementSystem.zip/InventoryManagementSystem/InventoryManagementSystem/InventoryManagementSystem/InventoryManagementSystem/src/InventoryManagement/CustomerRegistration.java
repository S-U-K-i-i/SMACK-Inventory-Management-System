/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package InventoryManagement;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import mycode.DBconnect;
import mycode.Validation;
import net.proteanit.sql.DbUtils;

/**
 *
 * @author POWER0
 */
public class CustomerRegistration extends javax.swing.JFrame {

    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;
    
    public CustomerRegistration() {
        initComponents();
        
        con = DBconnect.connect();
        
        tableload();
        customer_Id();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel13 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        name = new javax.swing.JTextField();
        phone = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        addressStreet = new javax.swing.JTextArea();
        jScrollPane2 = new javax.swing.JScrollPane();
        table = new javax.swing.JTable();
        jLabel6 = new javax.swing.JLabel();
        id = new javax.swing.JTextField();
        jPanel1 = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        update = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        addNew = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        clear = new javax.swing.JPanel();
        jLabel11 = new javax.swing.JLabel();
        jLabel12 = new javax.swing.JLabel();
        IdSearch = new javax.swing.JPanel();
        jLabel22 = new javax.swing.JLabel();
        nameSearch = new javax.swing.JPanel();
        jLabel21 = new javax.swing.JLabel();
        addressSearch = new javax.swing.JPanel();
        jLabel23 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        notificationLabel = new javax.swing.JLabel();
        addressNo = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        contactPerson = new javax.swing.JTextField();
        notificationBlank = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();

        jLabel13.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/backgroundW.jpg"))); // NOI18N
        jLabel13.setText("jLabel13");

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setMaximumSize(new java.awt.Dimension(1602, 780));
        setMinimumSize(new java.awt.Dimension(1602, 780));
        setUndecorated(true);
        getContentPane().setLayout(null);

        jLabel2.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel2.setText("Customer Id ");
        getContentPane().add(jLabel2);
        jLabel2.setBounds(120, 120, 117, 22);

        jLabel3.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel3.setText("Name ");
        getContentPane().add(jLabel3);
        jLabel3.setBounds(120, 210, 58, 22);

        jLabel4.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel4.setText("Address ");
        getContentPane().add(jLabel4);
        jLabel4.setBounds(120, 270, 76, 22);

        jLabel5.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel5.setText("Phone ");
        getContentPane().add(jLabel5);
        jLabel5.setBounds(120, 470, 63, 22);

        jLabel1.setBackground(new java.awt.Color(153, 0, 153));
        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 36)); // NOI18N
        jLabel1.setText("CUSTOMER REGISTRATION");
        getContentPane().add(jLabel1);
        jLabel1.setBounds(620, 40, 500, 30);

        name.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        name.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                nameActionPerformed(evt);
            }
        });
        getContentPane().add(name);
        name.setBounds(280, 200, 397, 45);

        phone.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        phone.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                phoneActionPerformed(evt);
            }
        });
        getContentPane().add(phone);
        phone.setBounds(280, 470, 320, 40);

        addressStreet.setColumns(20);
        addressStreet.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        addressStreet.setRows(5);
        jScrollPane1.setViewportView(addressStreet);

        getContentPane().add(jScrollPane1);
        jScrollPane1.setBounds(280, 310, 400, 60);

        table.setFont(new java.awt.Font("Tahoma", 0, 18)); // NOI18N
        table.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Customer Id ", "Customer Name ", "Address No", "Street", "Contact Person ", "Phone"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, true, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        table.setRowHeight(20);
        table.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tableMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(table);

        getContentPane().add(jScrollPane2);
        jScrollPane2.setBounds(780, 90, 720, 460);

        jLabel6.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        getContentPane().add(jLabel6);
        jLabel6.setBounds(1409, 624, 0, 0);

        id.setFont(new java.awt.Font("Verdana", 1, 14)); // NOI18N
        id.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                idActionPerformed(evt);
            }
        });
        getContentPane().add(id);
        id.setBounds(280, 110, 397, 45);

        jPanel1.setBackground(java.awt.Color.white);
        jPanel1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                jPanel1MouseClicked(evt);
            }
        });
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(34, 5, 10, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/home (6).png"))); // NOI18N
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 20, -1, -1));

        jLabel18.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/white.jpg"))); // NOI18N
        jLabel18.setText("jLabel18");
        jPanel1.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(-148, 260, 1540, 460));

        getContentPane().add(jPanel1);
        jPanel1.setBounds(1500, 0, 100, 100);

        update.setBackground(java.awt.Color.orange);
        update.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        update.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                updateMouseClicked(evt);
            }
        });
        update.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel9.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel9.setText("Update");
        update.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 20, -1, -1));

        jLabel14.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/edit-button.png"))); // NOI18N
        update.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 10, -1, 40));

        getContentPane().add(update);
        update.setBounds(610, 440, 160, 50);

        addNew.setBackground(java.awt.Color.orange);
        addNew.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        addNew.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addNewMouseClicked(evt);
            }
        });
        addNew.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel10.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel10.setText("Add");
        addNew.add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, -1));

        jLabel15.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/plus (2).png"))); // NOI18N
        addNew.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 0, -1, 40));

        getContentPane().add(addNew);
        addNew.setBounds(610, 510, 160, 50);

        clear.setBackground(java.awt.Color.orange);
        clear.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.LOWERED));
        clear.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clearMouseClicked(evt);
            }
        });
        clear.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel11.setText("Clear");
        clear.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(80, 10, -1, -1));

        jLabel12.setIcon(new javax.swing.ImageIcon(getClass().getResource("/InventoryManagement/rubber.png"))); // NOI18N
        clear.add(jLabel12, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 0, 50, 50));

        getContentPane().add(clear);
        clear.setBounds(610, 380, 160, 50);

        IdSearch.setBackground(java.awt.Color.white);
        IdSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        IdSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                IdSearchMouseClicked(evt);
            }
        });
        IdSearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel22.setIcon(new javax.swing.ImageIcon(getClass().getResource("/InventoryManagement/search (1).png"))); // NOI18N
        IdSearch.add(jLabel22, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 40));

        getContentPane().add(IdSearch);
        IdSearch.setBounds(700, 110, 40, 40);

        nameSearch.setBackground(java.awt.Color.white);
        nameSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        nameSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                nameSearchMouseClicked(evt);
            }
        });
        nameSearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel21.setIcon(new javax.swing.ImageIcon(getClass().getResource("/InventoryManagement/search (1).png"))); // NOI18N
        nameSearch.add(jLabel21, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 40));

        getContentPane().add(nameSearch);
        nameSearch.setBounds(700, 200, 40, 40);

        addressSearch.setBackground(java.awt.Color.white);
        addressSearch.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 2, true));
        addressSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                addressSearchMouseClicked(evt);
            }
        });
        addressSearch.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel23.setIcon(new javax.swing.ImageIcon(getClass().getResource("/InventoryManagement/search (1).png"))); // NOI18N
        addressSearch.add(jLabel23, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 0, 30, 40));

        getContentPane().add(addressSearch);
        addressSearch.setBounds(700, 290, 40, 40);

        jLabel16.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/backgroungO.jpg"))); // NOI18N
        jLabel16.setText("jLabel15");
        getContentPane().add(jLabel16);
        jLabel16.setBounds(0, 590, 850, 190);

        jLabel17.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/backgroungO.jpg"))); // NOI18N
        jLabel17.setText("jLabel16");
        getContentPane().add(jLabel17);
        jLabel17.setBounds(850, 590, 750, 190);
        getContentPane().add(notificationLabel);
        notificationLabel.setBounds(280, 440, 310, 20);

        addressNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addressNoActionPerformed(evt);
            }
        });
        getContentPane().add(addressNo);
        addressNo.setBounds(280, 260, 400, 40);

        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 18)); // NOI18N
        jLabel19.setText("Contact Person ");
        getContentPane().add(jLabel19);
        jLabel19.setBounds(120, 390, 150, 30);

        contactPerson.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                contactPersonActionPerformed(evt);
            }
        });
        getContentPane().add(contactPerson);
        contactPerson.setBounds(280, 380, 320, 40);

        notificationBlank.setText("jLabel20");
        getContentPane().add(notificationBlank);
        notificationBlank.setBounds(120, 536, 160, 30);

        jLabel20.setIcon(new javax.swing.ImageIcon(getClass().getResource("/mycode/backgroundW.jpg"))); // NOI18N
        jLabel20.setText("jLabel20");
        getContentPane().add(jLabel20);
        jLabel20.setBounds(0, 0, 1600, 590);

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void nameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_nameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_nameActionPerformed

    private void tableload() {
        try{
            String sql ="SELECT C_Id as Customer_Id,C_Name as Customer_Name,C_AdressNo as No, C_Street as Street, C_Contact as Contact_Person,C_Phone as Phone FROM customer";
            pst =  con.prepareStatement(sql);
            rs =  pst.executeQuery();
        
            table.setModel(DbUtils.resultSetToTableModel(rs));
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
    private void phoneActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_phoneActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_phoneActionPerformed

    private void idActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_idActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_idActionPerformed

    private void tableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tableMouseClicked
       int r = table.getSelectedRow();
        
        String cid = table.getValueAt(r, 0).toString();
        String cname = table.getValueAt(r, 1).toString();
        String caddressNo = table.getValueAt(r, 2).toString();
        String caddressStreet = table.getValueAt(r, 3).toString();
        String contact =  table.getValueAt(r, 4).toString();
        String cphone =  table.getValueAt(r, 5).toString();
        
        id.setText(cid);
        name.setText(cname);
        addressNo.setText(caddressNo);
        addressStreet.setText(caddressStreet);
        contactPerson.setText(contact);
        phone.setText(cphone);
        
    }//GEN-LAST:event_tableMouseClicked

    private void jPanel1MouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_jPanel1MouseClicked
        
        Homepage h = new Homepage();
        h.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jPanel1MouseClicked

    private void clearMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clearMouseClicked
       id.setText("");
        name.setText("");
        addressNo.setText("");
        addressStreet.setText("");
        contactPerson.setText("");
        phone.setText("");
    }//GEN-LAST:event_clearMouseClicked

    private void updateMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_updateMouseClicked
        int x = JOptionPane.showConfirmDialog(null, "Do you want to update?");
        
        if(x == 0){
            String sid = id.getText();
            String sname = name.getText();
            String caddressNo = addressNo.getText();
            String cStreet = addressStreet.getText();
            String sphone = phone.getText();
            String contact = contactPerson.getText();
            
            Validation validations = new Validation();
        
        String contact_Validation = validations.phonenumber_validation(sphone);
        
        
        try{
           if (contact_Validation.equals("false")&&!blank()) {
            
               
                String sql = "UPDATE customer set C_Id = '"+ sid + "', C_Name = '" + sname + "',C_AdressNo = '" +caddressNo + "',C_Street = '" +cStreet + "',C_contact = '" +contact + "',C_Phone = '" + sphone + "' where C_Id= "+ sid+"";
  
                pst = con.prepareStatement(sql);
                pst.execute();
                tableload();
            }else if(blank()){
                notificationBlank.setText("Please make sure all fields are filled in correctly");
            }
           else if(contact_Validation.equals("true")&&!blank()){
                notificationLabel.setText("Please enter valied contact number");
            }
            }catch(Exception e){
                System.out.println(e);
            }
        }    }//GEN-LAST:event_updateMouseClicked

    private boolean blank() {
        return id.getText().trim().isEmpty() || name.getText().trim().isEmpty() || addressNo.getText().trim().isEmpty() || phone.getText().trim().isEmpty() || addressStreet.getText().trim().isEmpty() || contactPerson.getText().trim().isEmpty();
    }
    
    private void addNewMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addNewMouseClicked
       
      //String cid = id.setText();
        String cname = name.getText();
        //String caddress = address.getText();
        String caddressNo = addressNo.getText();
        String cStreet = addressStreet.getText();
        String cphone = phone.getText();
        String contact = contactPerson.getText();
        
        Validation validations = new Validation();
        
        String contact_Validation = validations.phonenumber_validation(cphone);
        
        
        try{
            //System.out.println(blank());
           if (contact_Validation.equals("false")&&!blank()) {

            String q = "INSERT INTO customer (C_Name,C_AdressNo, C_Street, C_Contact, C_Phone)values('"+cname+"','"+caddressNo+"','"+cStreet+"','"+contact+"','"+cphone+"')";
            pst = con.prepareStatement(q);
            pst.execute();
            
            tableload();
           }else if(blank()){
                notificationBlank.setText("Please make sure all fields are filled in correctly");
            }
           else if(contact_Validation.equals("true")&&!blank()){
                notificationLabel.setText("Please enter valied contact number");
            }
        }catch(Exception e){
            
            System.out.println(e);
            
        }
    }//GEN-LAST:event_addNewMouseClicked

    private void IdSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_IdSearchMouseClicked
        String Id = id.getText();

        try{
            String sql = "SELECT C_Id, C_Name, C_AddressNo, C_Street, C_Contact, C_Phone from customer where C_Id LIKE '%"+Id+"%'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            table.setModel(DbUtils.resultSetToTableModel(rs));

        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_IdSearchMouseClicked

    private void nameSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_nameSearchMouseClicked
        String Name = name.getText();

        try{
            String sql = "SELECT C_Id, C_Name,  C_AddressNo, C_Street, C_Contact, C_Phone from customer where C_Name LIKE '%"+Name+"%'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            table.setModel(DbUtils.resultSetToTableModel(rs));

        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_nameSearchMouseClicked

    private void addressSearchMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_addressSearchMouseClicked
       String street = addressStreet.getText();

        try{
            String sql = "SELECT C_Id, C_Name, C_AddressNo, C_Street, C_Contact, C_Street, C_Phone from customer where C_Street LIKE '%"+street+"%'";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            table.setModel(DbUtils.resultSetToTableModel(rs));

        }catch(Exception e){
            System.out.println(e);
        }
    }//GEN-LAST:event_addressSearchMouseClicked

    private void addressNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addressNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_addressNoActionPerformed

    private void contactPersonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_contactPersonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_contactPersonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(CustomerRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(CustomerRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(CustomerRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(CustomerRegistration.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new CustomerRegistration().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel IdSearch;
    private javax.swing.JPanel addNew;
    private javax.swing.JTextField addressNo;
    private javax.swing.JPanel addressSearch;
    private javax.swing.JTextArea addressStreet;
    private javax.swing.JPanel clear;
    private javax.swing.JTextField contactPerson;
    private javax.swing.JTextField id;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField name;
    private javax.swing.JPanel nameSearch;
    private javax.swing.JLabel notificationBlank;
    private javax.swing.JLabel notificationLabel;
    private javax.swing.JTextField phone;
    private javax.swing.JTable table;
    private javax.swing.JPanel update;
    // End of variables declaration//GEN-END:variables

    private void customer_Id() {
       try{
            String sql = "Select MAX(C_Id) from customer ";
            pst = con.prepareStatement(sql);
            rs = pst.executeQuery();

            //int no = 0;
            if(rs.next()){
                int no = rs.getInt("MAX(C_Id)");
               // System.out.println(no);
                
                if(no == 0){
                id.setText("1");
            }else{
                no++;
                id.setText(String.valueOf(no));
            }
                   
            }
            
                 
        }catch(SQLException e){
            System.out.println(e);
        }
    }

    
    
    }
        

    

