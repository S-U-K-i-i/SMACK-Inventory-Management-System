-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 21, 2021 at 12:14 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smack`
--

-- --------------------------------------------------------

--
-- Table structure for table `balance_stock`
--

CREATE TABLE `balance_stock` (
  `Pr_Id` int(200) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Quantity` int(5) DEFAULT NULL,
  `Value` decimal(15,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `balance_stock`
--

INSERT INTO `balance_stock` (`Pr_Id`, `Pr_Name`, `Price`, `Quantity`, `Value`) VALUES
(102, '190 ml Glass Bottle', '46.80', 10, '468.00'),
(103, '190 ml Glass Bottle', '46.80', 5, '702.00'),
(105, '190 ml Glass Bottle', '46.80', 2, '93.60'),
(107, '190 ml Glass Bottle', '46.80', 5, '234.00'),
(110, '190 ml Glass Bottle', '46.80', 30, '2106.00'),
(111, '190 ml Glass Bottle', '46.80', 5, '468.00'),
(112, '190 ml Glass Bottle', '46.80', 0, '0.00'),
(115, '190 ml Glass Bottle', '46.80', 0, '0.00'),
(123, '190 ml Glass Bottle', '46.80', 0, '0.00'),
(1302, 'Tetra Pak ', '51.00', 22, '1122.00'),
(1303, 'Tetra Pak ', '51.00', 0, '0.00'),
(1304, 'Tetra Pak ', '51.00', 0, '0.00'),
(1305, 'Tetra Pak ', '51.00', 0, '0.00'),
(2502, '200 ml Nectar', '51.00', 0, '0.00'),
(2503, '200 ml Nectar', '51.00', 0, '0.00'),
(2505, '200 ml Nectar', '51.00', 0, '0.00'),
(2508, '200 ml Nectar', '51.00', 0, '0.00'),
(2514, '200 ml Nectar', '51.00', 0, '0.00'),
(2524, '200 ml Nectar', '51.00', 0, '0.00'),
(2526, '200 ml Nectar', '51.00', 0, '0.00'),
(2599, '200 ml Nectar', '59.50', 0, '0.00'),
(2802, '500 ml Nectar', '114.80', 0, '0.00'),
(2803, '500 ml Nectar', '114.80', 0, '0.00'),
(3333, '190 mi bottel ', '1000.00', -1000, '-1000000.00');

-- --------------------------------------------------------

--
-- Table structure for table `credit_collector`
--

CREATE TABLE `credit_collector` (
  `No` int(5) NOT NULL,
  `CC_Id` int(5) NOT NULL,
  `Date` date NOT NULL,
  `In_No` int(5) NOT NULL,
  `C_Id` int(5) NOT NULL,
  `C_Name` varchar(200) NOT NULL,
  `Amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `credit_collector`
--

INSERT INTO `credit_collector` (`No`, `CC_Id`, `Date`, `In_No`, `C_Id`, `C_Name`, `Amount`) VALUES
(2, 2, '2021-04-29', 2, 7, 'HERBERT KALANSOORIYA ', '400.00'),
(3, 1, '2021-05-20', 1, 1, 'ACHCHI KADE ', '10.00'),
(4, 1, '2021-05-20', 1, 1, 'ACHCHI KADE ', '100.00'),
(5, 3, '2021-05-20', 5, 5, 'CINAMAN LAKESIDE ', '100.00'),
(6, 3, '2021-05-20', 5, 5, 'CINAMAN LAKESIDE ', '100.00');

-- --------------------------------------------------------

--
-- Table structure for table `credit_sales`
--

CREATE TABLE `credit_sales` (
  `Collector_Id` int(5) NOT NULL,
  `In_No` int(5) NOT NULL,
  `Date` date NOT NULL,
  `C_Id` int(5) NOT NULL,
  `C_Name` varchar(100) NOT NULL,
  `Amount` decimal(10,2) DEFAULT NULL,
  `Remain_Amount` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `credit_sales`
--

INSERT INTO `credit_sales` (`Collector_Id`, `In_No`, `Date`, `C_Id`, `C_Name`, `Amount`, `Remain_Amount`) VALUES
(2, 2, '2021-04-29', 7, 'HERBERT KALANSOORIYA ', NULL, '1097.60'),
(3, 5, '2021-05-20', 5, 'CINAMAN LAKESIDE ', NULL, '268.00'),
(4, 13, '2021-05-20', 4, 'CHATHUMADURA ', NULL, '1588.86');

-- --------------------------------------------------------

--
-- Table structure for table `currentuser`
--

CREATE TABLE `currentuser` (
  `ID` int(10) NOT NULL,
  `User_Id` int(10) NOT NULL,
  `User_Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `C_Id` int(5) NOT NULL,
  `C_Name` varchar(200) DEFAULT NULL,
  `C_AdressNo` varchar(100) DEFAULT NULL,
  `C_Street` varchar(100) DEFAULT NULL,
  `C_Contact` varchar(100) DEFAULT NULL,
  `C_Phone` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`C_Id`, `C_Name`, `C_AdressNo`, `C_Street`, `C_Contact`, `C_Phone`) VALUES
(1, 'ACHCHI KADE ', 'Lotus Road', 'Colombo 01', '', '0774357890'),
(2, 'ALI BROS ', 'Lotus Road', 'Colombo 01', '', '0778907654'),
(3, 'BOC CANTEEN ', 'Clock Tower', 'Colombo 01', '', '0776875432'),
(4, 'CHATHUMADURA ', 'Main Street ', 'Colombo 01', '', '0756789543'),
(5, 'CINAMAN LAKESIDE ', 'Lotus Road ', 'Colombo 01', '', '0724567854'),
(6, 'ROWING CLUB ', 'Jayathilaka Road ', 'Colombo 01', '', '0723456784'),
(7, 'HERBERT KALANSOORIYA ', 'Lotus Road ', 'Colombo 01', '', '0775698765');

-- --------------------------------------------------------

--
-- Table structure for table `damages`
--

CREATE TABLE `damages` (
  `No` int(5) NOT NULL,
  `Date` date NOT NULL,
  `C_Id` int(5) NOT NULL,
  `Pr_Id` int(5) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `damages`
--

INSERT INTO `damages` (`No`, `Date`, `C_Id`, `Pr_Id`, `Pr_Name`, `Price`, `reason`) VALUES
(1, '2021-05-16', 1, 103, '190 ml Glass Bottle', '46.80', 'Damaged');

-- --------------------------------------------------------

--
-- Table structure for table `good_return`
--

CREATE TABLE `good_return` (
  `No` int(5) NOT NULL,
  `Date` date NOT NULL,
  `C_Id` int(5) NOT NULL,
  `Pr_Id` int(5) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `invoice_sales`
--

CREATE TABLE `invoice_sales` (
  `No` int(5) NOT NULL,
  `invoice_no` int(5) NOT NULL,
  `Pr_Id` int(100) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `Flavour` varchar(200) NOT NULL,
  `Unit_Price` decimal(10,2) NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Amount` decimal(15,2) NOT NULL,
  `Free_Issue` decimal(5,2) NOT NULL,
  `Discount` decimal(5,2) NOT NULL,
  `updated_Quantity` int(5) NOT NULL,
  `Total` decimal(20,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `market_return`
--

CREATE TABLE `market_return` (
  `No` int(5) NOT NULL,
  `Date` date NOT NULL,
  `C_Id` int(5) NOT NULL,
  `Pr_Id` int(5) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `reason` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `market_return`
--

INSERT INTO `market_return` (`No`, `Date`, `C_Id`, `Pr_Id`, `Pr_Name`, `Price`, `reason`) VALUES
(1, '2021-05-15', 1, 103, '190 ml Glass Bottle', '46.80', 'Expire'),
(2, '2021-05-15', 1, 105, '190 ml Glass Bottle', '46.80', 'Expired'),
(3, '2021-05-15', 1, 102, '190 ml Glass Bottle', '46.80', 'Expired');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Pr_Id` int(5) NOT NULL,
  `Type` varchar(100) NOT NULL,
  `Name` varchar(100) NOT NULL,
  `Flavour` varchar(100) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Discount` decimal(5,2) DEFAULT NULL,
  `Free_Issue` decimal(5,2) DEFAULT NULL,
  `Re_Level` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Pr_Id`, `Type`, `Name`, `Flavour`, `Price`, `Discount`, `Free_Issue`, `Re_Level`) VALUES
(102, 'Smak', '190 ml Glass Bottle', 'Mixed Fruit', '46.80', '0.03', '0.00', 50),
(103, 'Smak', '190 ml Glass Bottle', 'Mango ', '46.80', '0.03', '0.00', 50),
(105, 'Smak', '190 ml Glass Bottle', 'woodapple', '46.80', '0.03', '0.00', 50),
(107, 'Smak', '190 ml Glass Bottle', 'Lime', '46.80', '0.03', '0.00', 50),
(110, 'Smak', '190 ml Glass Bottle', 'Coffee', '46.80', '0.03', '0.00', 50),
(111, 'Smak', '190 ml Glass Bottle', 'Chocalate', '46.80', '0.03', '0.00', 50),
(112, 'Smak', '190 ml Glass Bottle', 'Sherbet', '46.80', '0.00', '0.00', 0),
(115, 'Smak', '190 ml Glass Bottle', 'Mixed/Lime', '46.80', '0.00', '0.00', 0),
(123, 'Smak', '190 ml Glass Bottle', 'Mango Blast', '46.80', '0.00', '0.00', 0),
(1302, 'Smak', 'Tetra Pak ', 'Mixed Fruit', '51.00', '0.03', '0.00', 50),
(1303, 'Smak', 'Tetra Pak ', 'Mango', '51.00', '0.00', '0.00', 0),
(1304, 'Smak', 'Tetra Pak ', 'Pineapple', '51.00', '0.00', '0.00', 0),
(1305, 'Smak', 'Tetra Pak ', 'woodapple', '51.00', '0.00', '0.00', 0),
(2502, 'Smak', '200 ml Nectar', 'Mixed Fruit', '51.00', '0.00', '0.00', 0),
(2503, 'Smak', '200 ml Nectar', 'Mango', '51.00', '0.00', '0.00', 0),
(2505, 'Smak', '200 ml Nectar', 'Woodapple', '51.00', '0.00', '0.00', 0),
(2508, 'Smak', '200 ml Nectar', 'Mixed / Lime', '51.00', '0.00', '0.00', 0),
(2514, 'Smak', '200 ml Nectar', 'Tamarind ', '51.00', '0.00', '0.00', 0),
(2524, 'Smak', '200 ml Nectar', 'Mandarin/Pap', '51.00', '0.00', '0.00', 0),
(2526, 'Smak', '200 ml Nectar', 'Ambarella ', '51.00', '0.00', '0.00', 0),
(2599, 'Smak', '200 ml Nectar', 'Alovera', '59.50', '0.00', '0.00', 0),
(2802, 'Smak', '500 ml Nectar', 'Mixed Fruit ', '114.80', '0.00', '0.00', 0),
(2803, 'Smak', '500 ml Nectar', 'Mango', '114.80', '0.00', '0.00', 0),
(3333, 'Smak', '190 mi bottel ', 'coconut ', '1000.00', '0.00', '0.00', 1000);

-- --------------------------------------------------------

--
-- Table structure for table `purchase_order`
--

CREATE TABLE `purchase_order` (
  `No` int(5) NOT NULL,
  `Pr_Id` int(5) NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Total` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `sale`
--

CREATE TABLE `sale` (
  `In_No` int(11) NOT NULL,
  `Date` date NOT NULL,
  `C_Id` int(11) NOT NULL,
  `C_Name` varchar(200) NOT NULL,
  `Payment_method` varchar(10) NOT NULL,
  `Discount` decimal(10,2) NOT NULL,
  `Free_Issue` decimal(5,2) NOT NULL,
  `Sub_Total` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sale`
--

INSERT INTO `sale` (`In_No`, `Date`, `C_Id`, `C_Name`, `Payment_method`, `Discount`, `Free_Issue`, `Sub_Total`) VALUES
(1, '2021-04-29', 1, 'ACHCHI KADE ', 'Credit', '0.00', '0.00', 1157),
(2, '2021-04-29', 7, 'HERBERT KALANSOORIYA ', 'Credit', '0.00', '0.00', 1498),
(3, '2021-05-15', 4, 'CHATHUMADURA ', 'Cash', '0.00', '0.00', 702),
(4, '2021-05-15', 2, 'ALI BROS ', 'Cash', '0.00', '0.00', 936),
(5, '2021-05-15', 5, 'CINAMAN LAKESIDE ', 'Credit', '0.00', '0.00', 468),
(6, '2021-05-15', 2, 'ALI BROS ', 'Cash', '14.04', '0.00', 454),
(7, '2021-05-16', 3, 'BOC CANTEEN ', 'Cash', '9.83', '0.00', 318),
(8, '2021-05-18', 4, 'CHATHUMADURA ', 'Cash', '11.24', '0.00', 363),
(9, '2021-05-18', 2, 'ALI BROS ', 'Cash', '12.63', '0.00', 409),
(10, '2021-05-20', 6, 'ROWING CLUB ', 'Cash', '0.00', '0.00', 11000000),
(11, '2021-05-20', 2, 'ALI BROS ', 'Cash', '14.04', '0.00', 454),
(12, '2021-05-20', 2, 'ALI BROS ', 'jLabel14', '14.04', '0.00', 454),
(13, '2021-05-20', 4, 'CHATHUMADURA ', 'Credit', '49.14', '0.00', 1589);

-- --------------------------------------------------------

--
-- Table structure for table `sales_return`
--

CREATE TABLE `sales_return` (
  `Date` date NOT NULL,
  `Return_Id` int(11) NOT NULL,
  `No` int(5) NOT NULL,
  `C_Id` int(11) NOT NULL,
  `C_Name` varchar(50) NOT NULL,
  `Pr_Id` int(11) NOT NULL,
  `Pr_Name` varchar(50) NOT NULL,
  `Flavour` varchar(50) NOT NULL,
  `Type` varchar(11) NOT NULL,
  `Reason` text NOT NULL,
  `return_type` varchar(50) NOT NULL,
  `Quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_in`
--

CREATE TABLE `stock_in` (
  `Ref_No` int(5) NOT NULL,
  `No` int(11) NOT NULL,
  `Date` date NOT NULL,
  `Pr_Id` int(5) NOT NULL,
  `Pr_Name` varchar(200) NOT NULL,
  `Flavour` varchar(20) NOT NULL,
  `Price` decimal(10,2) NOT NULL,
  `Quantity` int(5) NOT NULL,
  `Value` decimal(20,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `stock_out`
--

CREATE TABLE `stock_out` (
  `no` int(11) NOT NULL,
  `Pr_Id` int(11) NOT NULL,
  `Pr_Name` varchar(100) NOT NULL,
  `Quantity` int(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `stock_out`
--

INSERT INTO `stock_out` (`no`, `Pr_Id`, `Pr_Name`, `Quantity`) VALUES
(1, 107, '190 ml Glass Bottle', 12),
(2, 112, '190 ml Glass Bottle', 4),
(3, 1302, 'Tetra Pak ', 8),
(4, 110, '190 ml Glass Bottle', 12),
(5, 111, '190 ml Glass Bottle', 10),
(6, 103, '190 ml Glass Bottle', 0),
(7, 103, '190 ml Glass Bottle', 5),
(8, 105, '190 ml Glass Bottle', 10),
(9, 103, '190 ml Glass Bottle', 5),
(10, 103, '190 ml Glass Bottle', 5),
(11, 105, '190 ml Glass Bottle', 5),
(12, 103, '190 ml Glass Bottle', 5),
(13, 110, '190 ml Glass Bottle', 5),
(14, 103, '190 ml Glass Bottle', 4),
(15, 105, '190 ml Glass Bottle', 3),
(16, 102, '190 ml Glass Bottle', 4),
(17, 103, '190 ml Glass Bottle', 4),
(18, 102, '190 ml Glass Bottle', 3),
(19, 103, '190 ml Glass Bottle', 6),
(20, 3333, '190 mi bottel ', 11000),
(21, 110, '190 ml Glass Bottle', 10),
(22, 107, '190 ml Glass Bottle', 5),
(23, 107, '190 ml Glass Bottle', 5),
(24, 103, '190 ml Glass Bottle', 15),
(25, 103, '190 ml Glass Bottle', 5),
(26, 102, '190 ml Glass Bottle', 10),
(27, 103, '190 ml Glass Bottle', 10),
(28, 102, '190 ml Glass Bottle', 10),
(29, 111, '190 ml Glass Bottle', 5),
(30, 103, '190 ml Glass Bottle', 10),
(31, 110, '190 ml Glass Bottle', 20),
(32, 110, '190 ml Glass Bottle', 15);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `User_Id` int(10) NOT NULL,
  `User_Name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`User_Id`, `User_Name`, `password`) VALUES
(1, 'Sandamini', '1234'),
(2, 'oshadi', '5678');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `balance_stock`
--
ALTER TABLE `balance_stock`
  ADD PRIMARY KEY (`Pr_Id`);

--
-- Indexes for table `credit_collector`
--
ALTER TABLE `credit_collector`
  ADD PRIMARY KEY (`No`),
  ADD KEY `In_No` (`In_No`),
  ADD KEY `C_Id` (`C_Id`);

--
-- Indexes for table `credit_sales`
--
ALTER TABLE `credit_sales`
  ADD PRIMARY KEY (`Collector_Id`),
  ADD KEY `C_Id` (`C_Id`),
  ADD KEY `In_No` (`In_No`);

--
-- Indexes for table `currentuser`
--
ALTER TABLE `currentuser`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `User_Id` (`User_Id`);

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`C_Id`);

--
-- Indexes for table `damages`
--
ALTER TABLE `damages`
  ADD PRIMARY KEY (`No`),
  ADD KEY `C_Id` (`C_Id`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `good_return`
--
ALTER TABLE `good_return`
  ADD PRIMARY KEY (`No`),
  ADD KEY `C_Id` (`C_Id`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `invoice_sales`
--
ALTER TABLE `invoice_sales`
  ADD PRIMARY KEY (`No`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `market_return`
--
ALTER TABLE `market_return`
  ADD PRIMARY KEY (`No`),
  ADD KEY `C_Id` (`C_Id`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`Pr_Id`);

--
-- Indexes for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD PRIMARY KEY (`No`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `sale`
--
ALTER TABLE `sale`
  ADD PRIMARY KEY (`In_No`),
  ADD KEY `C_Id` (`C_Id`);

--
-- Indexes for table `sales_return`
--
ALTER TABLE `sales_return`
  ADD PRIMARY KEY (`No`),
  ADD KEY `C_Id` (`C_Id`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `stock_in`
--
ALTER TABLE `stock_in`
  ADD PRIMARY KEY (`No`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD PRIMARY KEY (`no`),
  ADD KEY `Pr_Id` (`Pr_Id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`User_Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `credit_collector`
--
ALTER TABLE `credit_collector`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `credit_sales`
--
ALTER TABLE `credit_sales`
  MODIFY `Collector_Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `currentuser`
--
ALTER TABLE `currentuser`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `C_Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `damages`
--
ALTER TABLE `damages`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `good_return`
--
ALTER TABLE `good_return`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `invoice_sales`
--
ALTER TABLE `invoice_sales`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `market_return`
--
ALTER TABLE `market_return`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `Pr_Id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3334;

--
-- AUTO_INCREMENT for table `purchase_order`
--
ALTER TABLE `purchase_order`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `sale`
--
ALTER TABLE `sale`
  MODIFY `In_No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `sales_return`
--
ALTER TABLE `sales_return`
  MODIFY `No` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `stock_in`
--
ALTER TABLE `stock_in`
  MODIFY `No` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `stock_out`
--
ALTER TABLE `stock_out`
  MODIFY `no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `User_Id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `balance_stock`
--
ALTER TABLE `balance_stock`
  ADD CONSTRAINT `balance_stock_ibfk_1` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `credit_collector`
--
ALTER TABLE `credit_collector`
  ADD CONSTRAINT `credit_collector_ibfk_1` FOREIGN KEY (`In_No`) REFERENCES `sale` (`In_No`),
  ADD CONSTRAINT `credit_collector_ibfk_2` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`);

--
-- Constraints for table `credit_sales`
--
ALTER TABLE `credit_sales`
  ADD CONSTRAINT `credit_sales_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`),
  ADD CONSTRAINT `credit_sales_ibfk_2` FOREIGN KEY (`In_No`) REFERENCES `sale` (`In_No`);

--
-- Constraints for table `currentuser`
--
ALTER TABLE `currentuser`
  ADD CONSTRAINT `currentuser_ibfk_1` FOREIGN KEY (`User_Id`) REFERENCES `user` (`User_Id`);

--
-- Constraints for table `damages`
--
ALTER TABLE `damages`
  ADD CONSTRAINT `damages_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`),
  ADD CONSTRAINT `damages_ibfk_2` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `good_return`
--
ALTER TABLE `good_return`
  ADD CONSTRAINT `good_return_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`),
  ADD CONSTRAINT `good_return_ibfk_2` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `invoice_sales`
--
ALTER TABLE `invoice_sales`
  ADD CONSTRAINT `invoice_sales_ibfk_1` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `market_return`
--
ALTER TABLE `market_return`
  ADD CONSTRAINT `market_return_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`),
  ADD CONSTRAINT `market_return_ibfk_2` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `purchase_order`
--
ALTER TABLE `purchase_order`
  ADD CONSTRAINT `purchase_order_ibfk_1` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `sale`
--
ALTER TABLE `sale`
  ADD CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`);

--
-- Constraints for table `sales_return`
--
ALTER TABLE `sales_return`
  ADD CONSTRAINT `sales_return_ibfk_1` FOREIGN KEY (`C_Id`) REFERENCES `customer` (`C_Id`),
  ADD CONSTRAINT `sales_return_ibfk_2` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `stock_in`
--
ALTER TABLE `stock_in`
  ADD CONSTRAINT `stock_in_ibfk_1` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);

--
-- Constraints for table `stock_out`
--
ALTER TABLE `stock_out`
  ADD CONSTRAINT `stock_out_ibfk_1` FOREIGN KEY (`Pr_Id`) REFERENCES `product` (`Pr_Id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
